var app = app || {};

(function($){
	
	app.Info = Backbone.Model.extend({
		defaults: {
		      name: '',
		      value: ''
		},

	});

	var InfoList = Backbone.Collection.extend({

	    // Reference to this collection's model.
	    model: app.Info,
	    
	});

	app.InfoList = InfoList;

	var InfoView = Backbone.View.extend({
			 
			 template: _.template( $('#row-template3').html()),
			 initialize: function (options) {
						
				this.options = options || {};
				this.model = options.model;
				this.parent = options.parent;
			 },
			 
			 events: {
				 'click #btn_delete': 'deleteRow',
			 },
			  
			 deleteRow: function(e){
				 
				 var obj = {model: this.model};
				 obj.view = this;
				 
				 this.parent.trigger('deleteItem', obj);
			 },
			 
			fetchEditor: function(){
				
				$.ajax({
					url: 'http://localhost'+ajaxurl,
					data: {
						action: 'get_wp_editor',
						editor_id: 'test'
					},
					dataType: 'html',
					success:function(response){
						
					}
				});
			},
			 
			afterRender: function(){
				
				tinyMCE.execCommand('mceAddEditor', false, this.editor_id);
				
			},
			render: function() {
				
				var viewData = {model: this.model};
					viewData.name = "Deepak";
				
				this.$el.html( this.template(viewData) );
				var ajaxResponse = '';
				var self = this;
				
				this.editor_id = "txt_"+this.model.cid;
				var editor_id = this.editor_id;
				setTimeout(function(){
					
					//tinyMCE.execCommand('mceAddEditor', false, editor_id);
				}, 200);
				
				/*
				$.ajax({
					url: 'http://localhost'+ajaxurl,
					aync: true,
					data: {
						action: 'get_wp_editor',
						editor_id: 'test'
					},
					success:function(response){
						ajaxResponse = response;
						
						self.$('td').html(ajaxResponse);
						
						var eid = 'test';
						
						//switchEditors.go(eid, 'tmce');
						///tinyMCE.execCommand('mceAddEditor', false, 'test')
						
				            //init quicktags
				            quicktags({id : eid});
				            
				           tinyMCEPreInit.mceInit[eid]['elements'] = eid;
				        	tinyMCEPreInit.mceInit[eid]['body_class'] = eid;
				        	tinyMCEPreInit.mceInit[eid]['succesful'] =  false;
				        	tinymce.init(tinyMCEPreInit.mceInit[eid]);
//				            //init tinymce
//				            tinymce.init(tinyMCEPreInit.mceInit['test']);
					}
				});*/
				


				return this;
			},
	});

	app.InfoView = InfoView;

	var InfoListView = Backbone.View.extend({
		 
		 el: '#additional_info_container',
		 tagName: '',
		 initialize: function (options) {
					
			this.options = options || {};
			
			this.collection = options.collection;
			
			this.collection.on('add', this.addOne, this);
			
			this.on('deleteItem', this.deleteItem);
			
		},
		
		addOne: function(model){
			
			var options = {};
				options.model = model;
				options.parent = this;
			
			  var view = new app.InfoView(options);
		      //this.$('tbody').append( view.render().el );
			  
			  this.$el.append( view.render().el );
			  
			  view.afterRender();
		},
		deleteItem : function(params){
			//console.log("InfoListView::deleteItem invoked", params);
			
			this.collection.remove(params.model);
			
			params.view.remove();
			//this.render();
		},
		render: function() {
			
			//this.$('tbody tr').not(':first').remove();
			this.$el.html('');
			
			this.collection.each(this.addOne, this);
			
			this.$el.show();
			
			return this;
			
			
		},
	});
	
   app.InfoListView = InfoListView;	
	
}(jQuery));


/**
 * Initialization script
 */
jQuery(document).ready(doInit);

var collection;
function doInit(){
	
	collection = new app.InfoList([
                                   {name: "Ida", age: 26},
                                   
                                 ]);
	
	
	var listView = new app.InfoListView({
			collection: collection
	});
	
	listView.render();
}

jQuery("#btn_add_additional_info").click(function(e){
	
	var obj = {name: "Tim", age: 5};
	
	collection.add(obj);
	
	
});


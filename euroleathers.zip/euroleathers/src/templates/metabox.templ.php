<!-- 
<table id="tbl_additional_infos" style="width:100%">
   <thead>
      <tr>
         <th class="left">Name</th>
         <th>Value</th>
      </tr>
   </thead>
   <tbody id="">
      <tr>
         <td></td>
      </tr>
     
   </tbody>
</table>
 -->
 
<div id="additional_info_container" class="woocommerce_options_panel">

</div>


<script type="text/template" id="row-template3">
 <div class="options_group">
	<p class="form-field ">
		<label for="_sku">Name:</label>
		<input type="text" placeholder="" value="" id="" name="" style="" class=""> 
		<input type="button"  value="Delete" class="button deletemeta button-small" id="btn_delete" name="">
	</p>
	<p class="form-field ">
		<label for="_sku">Value:</label>
		<textarea class="wp-editor-area" rows="20" autocomplete="off" cols="40" name="txt_<%= model.cid %>" id="txt_<%= model.cid %>"> <%= name %></textarea> 
	</p>
 </div>
</script>

<script type="text/template" id="row-template">
	<tr id="meta-55" style="">
	<td class="left">
	   <label for="meta-55-key" class="screen-reader-text">Key</label>
	   <input type="text" value="total_sales" size="20" id="meta-55-key" name="meta[55][key]">
	   <div class="submit">
	   	<input type="button"  value="Delete" class="button deletemeta button-small" id="btn_delete" name="">
	   </div>
	</td>
	<td>
		<label for="" class="screen-reader-text">Value</label>
		<textarea cols="30" rows="2" id="txt_info" name="">asdfsdf</textarea>

		<textarea class="wp-editor-area" rows="20" autocomplete="off" cols="40" name="test" id="test"></textarea></div>
	</td>
	</tr>
</script>


<script type="text/template" id="row-template2">
	<tr id="meta-55" style="">
	<td colspan="2">
	 <textarea class="wp-editor-area" autocomplete="off" name="test" id="test"></textarea>

	</td>
	
	</tr>
</script>


<div class="submit">
   <input type="button" value="Add Custom Field" class="button" id="btn_add_additional_info" name="btn_add_additional_info">
</div>
